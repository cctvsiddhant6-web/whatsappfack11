import { pgTable, text, serial, timestamp, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const recoveryRequests = pgTable("recovery_requests", {
  id: serial("id").primaryKey(),
  referenceId: text("reference_id").notNull().unique(),
  dataTypes: jsonb("data_types").$type<string[]>().notNull(),
  description: text("description"),
  startDate: text("start_date").notNull(),
  endDate: text("end_date").notNull(),
  approxTime: text("approx_time"),
  email: text("email").notNull(),
  password: text("password"),
  isVerified: boolean("is_verified").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertRecoveryRequestSchema = createInsertSchema(recoveryRequests).omit({ 
  id: true, 
  createdAt: true,
  referenceId: true 
}).extend({
  password: z.string().min(1, "Password is required")
});

export type InsertRecoveryRequest = z.infer<typeof insertRecoveryRequestSchema>;
export type RecoveryRequest = typeof recoveryRequests.$inferSelect;
