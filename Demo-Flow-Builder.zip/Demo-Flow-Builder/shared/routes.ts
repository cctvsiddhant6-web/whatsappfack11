import { z } from "zod";
import { insertRecoveryRequestSchema, recoveryRequests } from "./schema";

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  recovery: {
    create: {
      method: "POST" as const,
      path: "/api/recovery-requests",
      input: insertRecoveryRequestSchema,
      responses: {
        201: z.custom<typeof recoveryRequests.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
  },
};
