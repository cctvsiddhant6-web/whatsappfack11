import { recoveryRequests, type RecoveryRequest, type InsertRecoveryRequest } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";
import { customAlphabet } from "nanoid";

const nanoid = customAlphabet('0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ', 10);

export interface IStorage {
  createRecoveryRequest(request: InsertRecoveryRequest): Promise<RecoveryRequest>;
  getRecoveryRequest(referenceId: string): Promise<RecoveryRequest | undefined>;
}

export class DatabaseStorage implements IStorage {
  async createRecoveryRequest(insertRequest: InsertRecoveryRequest): Promise<RecoveryRequest> {
    const referenceId = `REF-${nanoid()}`;
    const [request] = await db
      .insert(recoveryRequests)
      .values({ ...insertRequest, referenceId })
      .returning();
    return request;
  }

  async getRecoveryRequest(referenceId: string): Promise<RecoveryRequest | undefined> {
    const [request] = await db
      .select()
      .from(recoveryRequests)
      .where(eq(recoveryRequests.referenceId, referenceId));
    return request;
  }
}

export const storage = new DatabaseStorage();
