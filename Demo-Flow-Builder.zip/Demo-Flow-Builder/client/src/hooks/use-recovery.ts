import { useMutation } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";
import { type InsertRecoveryRequest } from "@shared/schema";

export function useCreateRecoveryRequest() {
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async (data: InsertRecoveryRequest) => {
      const res = await fetch(api.recovery.create.path, {
        method: api.recovery.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      
      if (!res.ok) {
        if (res.status === 400) {
          const error = await res.json();
          throw new Error(error.message || "Validation failed");
        }
        throw new Error("Failed to submit recovery request");
      }
      
      return api.recovery.create.responses[201].parse(await res.json());
    },
    onError: (error) => {
      toast({
        title: "Submission Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}
