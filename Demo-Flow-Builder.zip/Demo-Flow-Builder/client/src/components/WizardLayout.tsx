import { ReactNode } from "react";
import logoImg from "@assets/Screenshot_2026-01-12_111117_1768196488408.png";

interface WizardLayoutProps {
  currentStep: number;
  totalSteps: number;
  children: ReactNode;
}

export function WizardLayout({ currentStep, totalSteps, children }: WizardLayoutProps) {
  return (
    <div className="min-h-screen bg-white flex flex-col items-center p-4 md:p-8 font-sans">
      {/* Top Header */}
      <div className="w-full max-w-6xl flex items-center justify-start mb-12">
        <img src={logoImg} alt="WhatsApp" className="h-12 md:h-14 object-contain" />
      </div>

      {/* Progress Stepper */}
      <div className="w-full max-w-2xl flex items-center justify-between mb-8 relative">
        <div className="absolute top-1/2 left-0 w-full h-px bg-slate-200 -z-10 -translate-y-1/2" />
        {[1, 2, 3, 4, 5].map((num) => (
          <div key={num} className="flex flex-col items-center gap-1">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-colors ${
              num <= currentStep ? 'bg-[#25D366] text-white' : 'bg-white border border-slate-200 text-slate-400'
            }`}>
              {num}
            </div>
            <span className="text-[10px] uppercase tracking-tighter font-bold text-slate-400">Step {num}</span>
          </div>
        ))}
      </div>

      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-slate-900 mb-2">Lost Your WhatsApp Data?</h1>
        <p className="text-slate-500 max-w-lg mx-auto leading-relaxed">
          Don't worry! This will guide you through the recovery process step by step.
        </p>
      </div>

      <div className="w-full max-w-4xl space-y-8">
        {children}
      </div>
    </div>
  );
}
