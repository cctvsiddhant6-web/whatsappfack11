## Packages
framer-motion | For smooth page transitions and step animations
lucide-react | Icons for the UI (already in base, but emphasizing usage)
date-fns | For date formatting and handling

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
